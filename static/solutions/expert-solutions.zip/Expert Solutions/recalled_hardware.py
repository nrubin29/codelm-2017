def is_palindrome(x):
    i = len(x) / 2

    for z in range(i):
        a = x[z]
        b = x[len(x) - z - 1]

        if a != b:
            return False

    return True


def recall(serial_number):
    factory_code = serial_number[0:3]
    state = serial_number[0:2]
    m = serial_number[3:5]
    month = int(m)
    y = serial_number[5:7]
    year = int(y)
    unique_id = serial_number[7:11]
    un_id = ''

    for i in range(len(unique_id)):
        if unique_id[i].isalpha():
            un_id += str(ord(unique_id[i]))

        else:
            un_id += unique_id[i]

    un_id_int = int(un_id)

    if is_palindrome(str(un_id_int)):
        return False

    else:
        if factory_code == 'PA6':
            return True

        elif state == 'NJ' and ((11 <= month <= 12 and year == 15) or (0 <= month <= 2 and year == 16)):
            return True

        elif month == 10 and (state == 'NY' or state == 'AK'):
            if un_id_int % 9 == 0 and un_id_int % 27 != 0:
                return False

            else:
                return True

        else:
            return False

print(recall(raw_input().strip()))