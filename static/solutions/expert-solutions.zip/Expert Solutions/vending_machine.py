import re


def vending_machine(pattern, combo):
    data = dict([(key, value) for key, value in pattern])
    done = []
    current = combo

    while re.match('[A-F][0-9]', current):
        if current not in data:
            return 'Nothing'

        current = data[current]

        if current in done:
            return 'Loop'

        else:
            done.append(current)

    return current


start = raw_input().strip()  # The starting point.
temp = raw_input().strip().split(' ')
stack_trace = [temp[x:x+2] for x in range(0, len(temp), 2)]  # a nxn list of characters.
print(vending_machine(stack_trace, start))
