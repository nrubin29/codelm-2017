from math import sqrt


def move(terrain, position, previous_positions, path=''):
    next_moves = ((position[0] + 1, position[1], 'D'), (position[0] - 1, position[1], 'U'), (position[0], position[1] + 1, 'R'), (position[0], position[1] - 1, 'L'))

    for x, y, direction in next_moves:
        if (x, y) in previous_positions or y < 0 or y >= len(terrain) or x < 0 or x >= len(terrain[y]):
            continue

        if terrain[x][y] is '|':
            continue

        if terrain[x][y] is 'O':
            yield path + direction
            raise StopIteration()

        for mv in move(terrain, (x, y), previous_positions + [(x, y)], path + direction):
            yield mv


def drive(terrain):
    start = None

    for i in range(len(terrain)):
        for j in range(len(terrain[i])):
            if terrain[i][j] == 'X':
                start = (i, j)
                break

    if not start:
        raise Exception('No starting position.')

    return min(list(move(terrain, start, [])), key=len)


temp = raw_input().split(' ')
row_length = int(sqrt(len(temp)))
terrain_map = [temp[x:x+row_length] for x in range(0, len(temp), row_length)]  # a nxn list of characters.
print(drive(terrain_map))