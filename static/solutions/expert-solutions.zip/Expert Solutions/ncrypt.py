special_words = [
    'NWPC',
    'New',
    'Wave',
    'Noah',
    'Rubin',
    'myPhone',
    'the',
    'and',
    'or',
    'I',
    'duct',
    'tape',
    'DDOS',
    'spontaneous',
    'combustion',
    'Newmeral',
    'smudged'
]


def encrypt(message, x):
    return ''.join(convert(letter, x) for letter in message)


def convert(letter, x):
    if ord('a') <= ord(letter) <= ord('z'):
        return chr((ord(letter) - ord('a') + x) % 26 + ord('a'))

    if ord('A') <= ord(letter) <= ord('Z'):
        return chr((ord(letter) - ord('A') + x) % 26 + ord('A'))

    return letter


def ncrypt(message):
    encypted_strings = []
    highest_score = 0
    highest_score_index = 0

    for a in range(26):
        enc = encrypt(message, a)
        score = 0
        encypted_strings.append(enc)
        words = enc.split(' ')
        try:
            words.remove('s')
        except ValueError:
            pass

        current_word = ''
        current_dict = ''
        partial_score = 0
        counter = 0
        multiplier = 0
        words_in_row = False

        for x in range(len(words)):
            words_in_row = False
            for y in range(len(special_words)):
                current_word = words[x]
                current_dict = special_words[y]

                if current_word == current_dict:
                    words_in_row = True
                    counter += 1

                    if counter > 1:
                        multiplier = counter

                    partial_score += len(current_word)

                    if x >= len(words) - 1:
                        score += partial_score * multiplier
                        counter = 0
                        multiplier = 1
                        partial_score = 0

            if not words_in_row:
                score += partial_score * multiplier
                counter = 0
                multiplier = 1
                partial_score = 0

        if score > highest_score:
            highest_score = score
            highest_score_index = a

    return 26 - highest_score_index

print(ncrypt(raw_input()))