def ncrypt(message, x, op):
    return ''.join(convert(letter, x, op) for letter in message)


def convert(letter, x, op):
    if ord('a') <= ord(letter) <= ord('z'):
        return chr((ord(letter) - ord('a') + (x if op == 'e' else 26 - (x % 26))) % 26 + ord('a'))

    if ord('A') <= ord(letter) <= ord('Z'):
        return chr((ord(letter) - ord('A') + (x if op == 'e' else 26 - (x % 26))) % 26 + ord('A'))

    return letter

print(ncrypt(raw_input(), int(raw_input()), raw_input()))