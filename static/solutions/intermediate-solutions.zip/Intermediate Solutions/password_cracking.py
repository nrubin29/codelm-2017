def cracking_probability(guess, lower, upper, answer):
    chance = 1
    gues = str(guess)
    answe = str(answer)

    for i in range(len(answe)):
        if gues[i] != '0':
            if answe[i] != gues[i]:
                return 0

        else:
            real_digit = int(answe[i])

            if lower <= real_digit <= upper:
                chance *= (1 / (float(upper) - (float(lower) - 1)))

            else:
                return 0

    return int(chance * 100)

print(cracking_probability(int(raw_input()), int(raw_input()), int(raw_input()), int(raw_input())))