def can_fly(path):
    batteries = 0
    starting_index = path.index('X')
    ending_index = path.index('O')

    if starting_index < ending_index:
        for i in range(starting_index, ending_index):
            if path[i] == '*':
                batteries += 1

            elif path[i] == '|':
                batteries -= 1

            if batteries < 0:
                return False

    else:
        for i in range(starting_index, ending_index, -1):
            if path[i] == '*':
                batteries += 1

            elif path[i] == '|':
                batteries -= 1

            if batteries < 0:
                return False

    return True

print(can_fly(raw_input()))