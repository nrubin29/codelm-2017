def recall(sn):
    identifier = sn % 1000
    sn /= 1000

    year = sn % 100
    sn /= 100

    month = sn % 100
    sn /= 100

    factory_code = sn % 100

    if factory_code == 66:
        return True

    if 9 <= factory_code <= 17:
        if year == 15 and (month == 11 or month == 12):
            return True

        elif year == 16 and month <= 2:
            return True

    if factory_code == 84 and year == 16 and month == 10:
        if identifier % 9 == 0 and identifier % 27 == 0:
            return False

        else:
            return True

    return False

print(recall(int(raw_input())))