import math


def alternate(a, b):
    a_idx = 0
    b_idx = 0
    which = True

    while a_idx < len(a) or b_idx < len(b):
        if which:
            yield a[a_idx]
            a_idx += 1

        else:
            yield b[b_idx]
            b_idx += 1

        which = not which


def calculate(a, b, operation):
    if operation == ':':
        split_factor = min(len(a), len(b))  # The length of pieces in which to split each newmeral.

        a_split_len = int(math.ceil(float(len(a)) / split_factor))
        a_split = [a[x:x+a_split_len] for x in range(0, len(a) - a_split_len + 1, a_split_len)]

        b_split_len = int(math.ceil(float(len(b)) / split_factor))
        b_split = [b[x:x + b_split_len] for x in range(0, len(b) - b_split_len + 1, b_split_len)]

        return ''.join(alternate(a_split, b_split))

    elif operation == '^':
        a = list(reversed(a))
        b = list(reversed(b))
        result = []

        for i in range(min(len(a), len(b))):
            result += max(a[i], b[i]) if a[i] is not b[i] else chr(ord(a[i]) + 1) if a[i] is not 'D' and b[i] is not 'D' else 'A'

        result += max(a, b, key=len)[min(len(a), len(b)):]

        return ''.join(reversed(result))

    elif operation == '%':
        return ''.join(reversed(b)) + a + b


print(calculate(raw_input().strip(), raw_input().strip(), raw_input().strip()))