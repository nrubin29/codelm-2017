from math import sqrt


def calculate(matrix):
    if len(matrix) is 2:
        return (matrix[0][0] + matrix[1][1]) - (matrix[0][1] + matrix[1][0])

    sub_matrices = []

    for row in range(2):
        for col in range(2):
            sub_matrix = [matrix[r][col:col + len(matrix) - 2 + 1] for r in range(row, row + len(matrix) - 2 + 1)]
            sub_matrices.append(sub_matrix)

    return (calculate(sub_matrices[0]) + calculate(sub_matrices[3])) - (calculate(sub_matrices[1]) + calculate(sub_matrices[2]))

temp = [int(x) for x in raw_input().split(' ')]
row_length = int(sqrt(len(temp)))
code = [temp[x:x+row_length] for x in range(0, len(temp), row_length)]  # a nxn list of ints.
print(calculate(code))
