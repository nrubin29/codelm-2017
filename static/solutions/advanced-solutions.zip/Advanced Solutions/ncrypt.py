words = [
    'NWPC',
    'New',
    'Wave',
    'Noah',
    'Rubin',
    'myPhone',
    'the',
    'and',
    'or',
    'I',
    'duct',
    'tape',
    'DDOS',
    'spontaneous',
    'combustion',
    'Newmeral',
    'smudged'
]


def ncrypt(message):
    best_rot = None
    best_score = None
    best_x = None

    for x in range(26):
        rot = ''.join(convert(letter, x) for letter in message)
        score = 0

        for word in words:
            if word in rot.split(' '):
                score += len(word)

        if not best_score or score > best_score:
            best_score = score
            best_rot = rot
            best_x = x

    return 0 if not best_x else 26 - best_x


def convert(letter, x):
    if ord('a') <= ord(letter) <= ord('z'):
        return chr((ord(letter) - ord('a') + x) % 26 + ord('a'))

    if ord('A') <= ord(letter) <= ord('Z'):
        return chr((ord(letter) - ord('A') + x) % 26 + ord('A'))

    if ord('0') <= ord(letter) <= ord('9'):
        return chr((ord(letter) - ord('0') + x) % 10 + ord('0'))

    return letter

print(ncrypt(raw_input().strip()))