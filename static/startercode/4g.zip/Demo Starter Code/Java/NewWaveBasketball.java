import java.util.Scanner;

public class NewWaveBasketball {
	static Scanner s = new Scanner(System.in);
	
	// New Wave is gearing up for their basketball game against SIG. Half of their employees have 
	// even-numbered jerseys, and the other half have odd-numbered jerseys. For this game, only the 
	// players with even-numbered jerseys will play. Given a jersey number, determine if the player will play.

	public static void main(String[] args) {
		int jerseyNumber = s.nextInt();					                  // a player's jersey number.
	
		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                                 // print your answer and just your answer.
	}
}