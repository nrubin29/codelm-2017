import random
import combination_guesser as cg


def evaluate(guess, combination):
    """
    This method is passed a guess and the actual combination. It will construct a string of 0s and 1s that represents how many digits in the guess are correct. 0 means correct digit at correct location, 1 means correct digit at the wrong location.
    :param guess: The guess that will be evaluated.
    :param combination: The correct combination.
    :return: An evaluation.
    """
    res = list('----')

    for i in range(len(guess)):
        if guess[i] == combination[i]:
            res[i] = '0'

    for i in range(4):
        for j in range(4):
            if res[i] == '-' and guess[i] == combination[j]:
                res[i] = '1'

    return ''.join(res)


def main():
    """
    This is the main function.  You can edit this function, but any changes that you make will not be kept when your algorithm is tested.
    """
    # This will randomly generate a valid combination.
    combination = ''.join(chr(random.randint(48, 53)) for _ in range(4))
    print('The combination is ' + combination)

    # Used to keep track of how many guesses it takes to find the correct combination.
    total_guesses = 0

    # These strings will be used to keep track of each guess that you make, and what that guess evaluates to.  Starts with '9999', which would return a evaluation of '----'.
    last_guess = '9999'
    evaluation = '----'

    while last_guess != combination:
        last_guess = cg.guess(last_guess, evaluation)
        evaluation = evaluate(last_guess, combination)
        print(last_guess + ' ' + evaluation)
        total_guesses += 1

    print('It took {} guesses.'.format(total_guesses))

if __name__ == '__main__':
    main()