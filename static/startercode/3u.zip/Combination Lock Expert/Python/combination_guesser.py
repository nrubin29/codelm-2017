import random

# This file contains starter code for you to use when you write your algorithm to figure out the combination to New Wave Computer's vault.
# You should not change the evaluate function.

school_name = ''  # set this string equal to your school's name.


def guess(last_guess, evaluation):
    """
    This is the one function that you should modify.
    It is passed the last guess that was made along with the evaluation for that guess.
    You should use this information to make an informed guess about the combination.
    :param last_guess: The last guess that was made.
    :param evaluation: A collection of 0s and 1s that represent how the guess was evaluated.
    :return: The next guess. Right now this method will just return a random guess.You should improve this method so that it uses what you know about the last guess to make a more educated guess.
    """
    return ''.join(chr(random.randint(48, 53)) for _ in range(4))
