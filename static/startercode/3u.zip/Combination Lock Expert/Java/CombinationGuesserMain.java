import java.util.Arrays;
import java.util.Collections;
import java.util.List;

// class: CombinationGuesser
// written by: Mr. Swope
// date: 2/4/17
// description: This class contains starter code for you to use when you write your algorithm to figure out
//              the combination to New Wave Computer's vault.  YOU SHOULD NOT MODIFY THIS CLASS AS ANY CHANGES
//              THAT YOU MAKE WILL NOT BE REFLECTED IN THE CODE THAT IS USED TO TEST YOUR ALGORITHM.
public class CombinationGuesserMain{

	static CombinationGuesser guesser;

	public static void main(String[] args){

		// This will randomly generate a 4-digit combination.  Each digit will be between 0 and 5, inclusive.
		// 48 is added to each digit because these digits are being concatenated to a String as chars and  
		// '0' has an ascii value of 48, '1' has an ascii value of '49', '2' has an ascii value of '50', etc. 
		// Although you have access to this variable to test your algorithm, it is important to understand that
		// will not be able to access it when your algorithm is tested by the judges.
		String combination = "";
		for(int i=0; i<4; i++)
			combination+=(char)((Math.random()*6)+48);
		
		// Instantiate a new CombinationGuesser
		guesser = new CombinationGuesser();
		
		// Used to keep track of how many guesses it takes to find the correct combination.
		int totalGuesses = 0;                     

		// These strings will be used to keep track of each guess that you make, and what that guess 
		// evaluates to.  Starts with '9999', which would return a evaluation of '----'.
		String lastGuess = "9999";
		String evaluation = "----";
		
		// This loop will continue until your guess matches the correct combination.		
		do{
			lastGuess = guesser.guess(lastGuess, evaluation);
			evaluation = evaluate(lastGuess, combination);
			totalGuesses++;
			System.out.println(lastGuess + " " + evaluation);
		}while(!lastGuess.equals(combination));
		
		System.out.println("It took " + totalGuesses + " guesses.");
	}

	// method: evaluate
	// description: This method is passed a guess and the actual combination.  It will construct a String
	//              of '0's and '1's that represents how many digits in the guess are correct. '0' means
	//              correct digit at correct location, '1' means correct digit at the wrong location.
	// parameters:  String guess: The guess that will be evaluated.
	//              String combination:  The correct combination.
	// return: a string of 1's and 0's that signifies how the String was evaluated.
	public static String evaluate(String guess, String answer){

		String eval = "";

		for(int i= answer.length()-1; i>=0; i--){
			for(int j=guess.length()-1; j>=0; j--){

				if(answer.charAt(i) == guess.charAt(j) && i == j){
					eval += '0';

					answer = answer.substring(0, i) + answer.substring(i+1);
					guess = guess.substring(0, j) + guess.substring(j+1);
					break;
				}
			}
		}

		for(int i= answer.length()-1; i>=0; i--){
			for(int j=guess.length()-1; j>=0; j--){

				if(answer.charAt(i) == guess.charAt(j)){
					eval += '1';
					answer = answer.substring(0, i) + answer.substring(i+1);
					guess = guess.substring(0, j) + guess.substring(j+1);
					break;
				}
			}
		}
		return shuffle(eval);
	}

	// method: shuffle
	// description: This method is used to sort the evaluation String.
	// parameters:  String guess: The guess that will be evaluated.
	//              String combination:  The correct combination.
	// return: a string of 1's and 0's that signifies how the String was evaluated.
	public static String shuffle(String eval)
	{
		List<String> letters = Arrays.asList(eval.split(""));
		Collections.shuffle(letters);
		String shuffled = "";
		for (String letter : letters) {
			shuffled += letter;
		}
		return shuffled;
	}
}
