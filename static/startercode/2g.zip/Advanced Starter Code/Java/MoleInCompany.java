import java.util.Scanner;

public class MoleInCompany {
	static Scanner s = new Scanner(System.in);
	
	// Secret messages passed to a competing company have recently been intercepted.  Implement the algorithm 
	// and find the mole.
	// 
	// The variable code has been declared for you along with code that will read values into this variable.
	// Write code that evaluates and prints the given values.  Do not print anything else or it will be marked wrong.
	//
	// When you are finished, copy and paste the the entire contents of this file into the employee
	// dashboard to test your algorithm.
	//
	// sample data to copy into input stream
	// 1 4 4 0
	// 1 2 3 4 5 6 7 8 9
	// 4 6 1 5 2 1 9 2 0 4 3 1 5 3 2 1
	// 1 3 5 6 7 2 9 1 4 2 5 6 1 2 8 9 2 3 4 1 5 0 2 1 5
	// 2 3 1 0 3 4 7 1 3 4 5 6 7 2 9 0 1 8 2 3 4 1 2 3 4 5 6 7 2 3 4 5 6 7 8 1 8 0 2 3 2 1 2 1 3 4 5 2 1
	
	public static void main(String[] args) {
		int[][] code;					                               // a nxn array of ints.
		
		// The following code will read in the ints from the input stream and fill the 2d array.
		String[] temp = s.nextLine().split(" ");
		code = new int[(int) Math.sqrt(temp.length)][(int) Math.sqrt(temp.length)];
		
		int counter = 0;
		for(int i=0; i<(int) Math.sqrt(temp.length); i++){
			for(int j=0; j<(int) Math.sqrt(temp.length); j++){
				code[i][j] = new Integer(temp[counter]).intValue();
				counter++;
			}
		}

		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                                 // print your answer and just your answer.
	}
}
