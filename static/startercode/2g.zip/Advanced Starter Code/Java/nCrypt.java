import java.util.Scanner;

public class nCrypt {
	
	static Scanner s = new Scanner(System.in);
	
	// New Wave has decided to encrypt all of their communications so that attackers cannot steal 
	// their trade secrets.  Write a program that will encrypt and decrypt these messages.
	// 
	// message has been declared for you along with code that will read in a values for this variable.
	// Write code that determines and prints the most probable offset. Do not print anything else or 
	// it will be marked wrong.
	//
	// When you are finished, copy and paste the the entire contents of this file into the employee
	// dashboard to test your algorithm.
	//
	// sample data to copy into input stream
	// Opbi Svcjo hpu EEPTfe
	// Uovigf hygx xeti.
	
	public static void main(String[] args) {
		String message = s.nextLine();           // The message that is to be either encrypted or decrypted.

		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                     // print your answer and just your answer.
	}


}
