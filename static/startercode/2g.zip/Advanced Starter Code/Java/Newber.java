import java.util.Scanner;

public class Newber {
	static Scanner s = new Scanner(System.in);
	
	// New Wave’s automated car service, Newber, has received reports that the navigation system in their cars 
	// has come under attack.  Determine the best path to return the cars for service.
	// 
	// char[][] map has been declared for you along with code that will read values into this variable.
	// Write code that determines the best path for the car and then print this path.  Do not print anything 
	// else or it will be marked wrong.
	//
	// When you are finished, copy and paste the the entire contents of this file into the employee
	// dashboard to test your algorithm.
	//
	// sample data to copy into input stream
	// X - | - - | - - - - | O | - - -
	// - - - - | - | - | X | O | - - -
	// 0 - - - | - | - | | | X | - - -
	
	public static void main(String[] args) {
		char[][] map = new char[4][4];
		
		for(int i=0;i<4;i++)
			for(int j=0;j<4;j++)
				map[i][j] = s.next().charAt(0);

		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                     // print your answer and just your answer.
	}
}
