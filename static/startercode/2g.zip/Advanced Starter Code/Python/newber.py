from math import sqrt

# New Wave's automated car service, Newber, has received reports that the navigation system in their cars
# has come under attack.  Determine the best path to return the cars for service.
#
# 2D list map has been declared for you along with code that will read values into this variable.
# Write code that determines the best path for the car and then print this path.  Do not print anything
# else or it will be marked wrong.
#
# When you are finished, copy and paste the the entire contents of this file into the employee
# dashboard to test your algorithm.
# sample data to copy into input stream
# X - | - - | - - - - | O | - - -
# - - - - | - | - | X | O | - - -
# 0 - - - | - | - | | | X | - - -

temp = raw_input().split(' ')
row_length = int(sqrt(len(temp)))
terrain_map = [temp[x:x+row_length] for x in range(0, len(temp), row_length)]  # a nxn list of characters.

# code to solve the problem.  You can write and call functions as well.

print  # print your answer and just your answer.