import java.util.Scanner;

public class NestedBrackets {
	
	static Scanner s = new Scanner(System.in);
	//	Write a program that reads a sequence of ( ) { } [ ] followed by a *, checks whether brackets are valid
	//  and prints out 'yes' if they are or 'no' if they are not.
	//
	//  Do not print anything else or your solution will be marked wrong.
	//		
	//	When you are finished, copy and paste the the entire contents of this file into the employee
	//	dashboard to test your algorithm.
	public static void main(String[] args) {
		String sequence = s.nextLine();
		
		// code to solve the problem.  You can write and call other methods as well.
		
	}

}
