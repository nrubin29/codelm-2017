import java.util.Scanner;

public class MagicSquare {

	static Scanner s = new Scanner(System.in);
	//  A square array of numbers is said to be a "magic square" if all the rows, columns, and diagonals 
	//  add up to the same number.  Write a program which takes any 9 integers as inputs, prints out the 
	//  3 by 3 square which they form, and then a YES or NO according to whether the square is a magic square or not.
	//
	//  Do not print anything else or your solution will be marked wrong.
	//
	//	When you are finished, copy and paste the the entire contents of this file into the employee
	//	dashboard to test your algorithm.
	public static void main(String[] args) {
		

	}

}
