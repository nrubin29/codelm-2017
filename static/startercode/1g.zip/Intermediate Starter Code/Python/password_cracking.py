# An employee at New Wave Computers has stolen confidential documents and stored them on a laptop 
# that is protected with a five-digit password.  Determine the possibility of correctly guessing
# this combination.
#
# Four variables have been declared for you along with code that will read a values into these variable.
# Write code that determines and prints this probably as a whole number.  Do not print anything else or
# it will be marked wrong.
#
# When you are finished, copy and paste the the entire contents of this file into the employee
# dashboard to test your algorithm.
# sample data to copy into input stream
# 12021 1 9 12421
# 10401 1 5 12431
# 12021 5 9 12421
# 54021 1 5 12345

guess = int(raw_input())   # A five-digit integer.
lower = int(raw_input())   # The lower bound.
upper = int(raw_input())   # The upper bound.
answer = int(raw_input())  # The correct password.

# code to solve the problem.  You can write and call functions as well.

print  # print your answer and just your answer.