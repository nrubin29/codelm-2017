# New Wave Computers has decided to deploy a fleet of delivery drones.  write a program that 
# can determine if a drone will be able to make its delivery based on the number of obstacles
# and battery packs that it will encounter along its route.
#
# String path has been declared for you along with code that will read a value into this variable.
# Write code that determines whether or not the drone can make its delivery and then prints either 'True'
# or 'False'.  Do not print anything else or it will be marked wrong.
#
# When you are finished, copy and paste the the entire contents of this file into the employee
# dashboard to test your algorithm.
# sample data to copy into input stream
# X—*|—O
# O---*|---X
# X--**|||*-O
# *X---|--O

path = raw_input()  # The drone's delivery path.

# code to solve the problem.  You can write and call functions as well.

print  # print your answer and just your answer.