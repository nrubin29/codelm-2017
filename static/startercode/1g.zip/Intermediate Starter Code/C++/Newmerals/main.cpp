// In order to improve security, New Wave Computers wants to implement a proprietary number system
// named Newmerals.  Combine two of these Newmerals using the give operator.
//
// Three variables have been declared for you along with code that will read in values for them.
// Write code that combines the two Newmerals using operator and then prints this new Newmeral.
// Your code should not print anything else or it will be marked wrong.
//
// When you are finished, copy and paste the the entire contents of this file into the employee
// dashboard to test your algorithm.
// sample data to copy into input stream
// AC BD :
// AD CD ^
// AC DC %

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    string newmeralA;     // The first newmeral.
    string newmeralB;     // The second newmeral.
    char operation;       // The operator, ':', '^' or '%'.
    cin >> newmeralA;
    cin >> newmeralB;
    cin >> operation;
    
    // code to solve the problem.  You can write and call other methods as well.
    
    return 0;
}
