// New Wave Computers has decided to deploy a fleet of delivery drones.  write a program that
// can determine if a drone will be able to make its delivery based on the number of obstacles
// and battery packs that it will encounter along its route.
//
// String path has been declared for you along with code that will read a value into this variable.
// Write code that determines whether or not the drone can make its delivery and then prints either 'true'
// or 'false'.  Do not print anything else or it will be marked wrong.
//
// When you are finished, copy and paste the the entire contents of this file into the employee
// dashboard to test your algorithm.
// sample data to copy into input stream
// X---*|--O
// O---*|---X
// X--**|||*-O
// *X---|--O

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {
    string path;                   // The drone's delivery path.
    cin >> path;
    
    // code to solve the problem.  You can write and call other methods as well.
    
    return 0;
}
