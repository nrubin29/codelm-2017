import java.util.Scanner;

public class Newmerals {

	static Scanner s = new Scanner(System.in);

	// In order to improve security, New Wave Computers wants to implement a proprietary number system 
	// named Newmerals.  Combine two of these Newmerals using the give operator.
	// 
	// Three variables have been declared for you along with code that will read in values for them.
	// Write code that combines the two Newmerals using operator and then prints this new Newmeral. 
	// Your code should not print anything else or it will be marked wrong.
	//
	// sample data to copy into input stream
	// AC BD :
	// AD CD ^
	// AC DC %
	//
	// When you are finished, copy and paste the the entire contents of this file into the employee
	// dashboard to test your algorithm.

	public static void main(String[] args) {
		String newmeralA = s.next();              // The first newmeral.
		String newmeralB = s.next();              // The second newmeral.
		char operator = s.next().charAt(0);       // The operator, ':', '^' or '%'.

		// code to solve the problem.  You can write and call other methods as well.

		System.out.println();                     // print your answer and just your answer.
	}

}
