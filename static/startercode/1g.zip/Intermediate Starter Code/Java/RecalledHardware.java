import java.util.Scanner;

public class RecalledHardware {

	static Scanner s = new Scanner(System.in);
	
	// New Wave Computer’s new product, the Universe Edge, has had some minor “malfunctions”.  
	// Design a program that receives a serial number and determines if the phone is faulty.
	// 
	// int serialNumber has been declared for you.
	// Write code that determines whether or not the phone should be recalled and then print either 'true'
	// or 'false'.  Do not print anything else or it will be marked wrong.
	//
	// sample data to copy into input stream
	// 660915123
	// 110915327
	// 111115893
	//
	// When you are finished, copy and paste the the entire contents of this file into the employee
	// dashboard to test your algorithm.
	
	public static void main(String[] args) {
		int serialNumber = s.nextInt();      // A nine digit serial number.

		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                // print your answer and just your answer.
	}

}
