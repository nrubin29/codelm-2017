import java.util.Scanner;

public class PasswordCracking {
	static Scanner s = new Scanner(System.in);
	
	// An employee at New Wave Computers has stolen confidential documents and stored them on a laptop 
	// that is protected with a five-digit password.  Determine the possibility of correctly guessing
	// this combination.
	// 
	// Four variables have been declared for you along with code that will read a values into these variable.
	// Write code that determines and prints this probably as a whole number.  Do not print anything else or 
	// it will be marked wrong.
	//
	// sample data to copy into input stream
	// 12021 1 9 12421
	// 10401 1 5 12431
	// 12021 5 9 12421
	// 54021 1 5 12345
	//
	// When you are finished, copy and paste the the entire contents of this file into the employee
	// dashboard to test your algorithm.
	
	public static void main(String[] args) {
		int guess = s.nextInt();              // A five-digit integer.
		int lower = s.nextInt();			  // The lower bound.
		int upper = s.nextInt();			  // The upper bound.
		int answer = s.nextInt();             // The correct password.

		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                     // print your answer and just your answer.
	}
}
