// The vending machines in the New Wave headquarters are acting up.  write a program that will take the
// stack-trace and determine what the result will be, whether it is a snack, dead end, or an infinite loop.
//
// Two variables have been declared for you along with code that will read values into these variables.
// Write code that determines and prints this probably the results of the path.  Do not print anything
// else or it will be marked wrong.
//
// When you are finished, copy and paste the the entire contents of this file into the employee
// dashboard to test your algorithm.
// sample data to copy into input stream
// X - | - - | - - - - | O | - - -
// - - - - | - | - | X | O | - - -
// 0 - - - | - | - | | | X | - - -

#include <iostream>
using namespace std;

int main(int argc, const char * argv[]) {

    // All data will be entered in a single line of input.
    
    return 0;
}
