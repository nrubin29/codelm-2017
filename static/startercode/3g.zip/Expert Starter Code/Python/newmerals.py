# In order to improve security, New Wave Computers wants to implement a proprietary number system 
# named Newmerals.  Combine two of these Newmerals using the give operator.
#
# Three variables have been declared for you along with code that will read in values for them.
# Write code that combines the two Newmerals using operator and then prints this new Newmeral.
# Your code should not print anything else or it will be marked wrong.
#
# When you are finished, copy and paste the the entire contents of this file into the employee
# dashboard to test your algorithm.
# sample data to copy into input stream
# ACD BDBCDD :
# AD CD ^
# AC DC %

newmeralA = raw_input()  # The first newmeral.
newmeralB = raw_input()  # The second newmeral.
operator = raw_input()   # The operator, ':', '^' or '%'.

# code to solve the problem.  You can write and call functions as well.

print  # print your answer and just your answer.