import java.util.Scanner;

public class VendingMachine {
	static Scanner s = new Scanner(System.in);
	
	// The vending machines in the New Wave headquarters are acting up.  write a program that will take the 
	// stack-trace and determine what the result will be, whether it is a snack, dead end, or an infinite loop.
	// 
	// Two variables have been declared for you along with code that will read values into these variables.
	// Write code that determines and prints this probably the results of the path.  Do not print anything 
	// else or it will be marked wrong.
	//
	// When you are finished, copy and paste the the entire contents of this file into the employee
	// dashboard to test your algorithm.
	//
	// sample data to copy into input stream
	// A6 E5 D4 D4 B2 F5 C3 A6 B9 C4 D6 B9 F5 B2 E5 C3 PopTart
	// C4 E5 D4 D4 B2 F5 C3 A6 B9 C4 D6 B9 F5 B2 E5 C3 PopTart
	// B2 E5 D4 D4 B2 F5 C3 A6 B9 C4 D6 B9 F5 B2 E5 C3 Poptart
	
	public static void main(String[] args) {
		String start = s.next();            // The starting point.
		String[][] path;					// a nx2 array of points.
		
		// The following code will read in the points from the input stream and fill the array.
		String input = s.nextLine().trim();
		String[] temp = input.split(" ");
		path = new String[temp.length/2][2];
		
		int counter = 0;
		for(int i=0; i<temp.length/2; i++){
			for(int j=0; j<2; j++){
				path[i][j] = temp[counter];
				counter++;
			}
		}

		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                     // print your answer and just your answer.
	}
}
