// class: CombinationGuesser
// written by: Mr. Swope
// date: 2/4/17
// description: This class contains starter code for you to use when you write your algorithm to figure out
//              the combination to New Wave Computer's vault.  If you want to add any class level variables
//              be sure to add them above the guess method.  If you declare them anywhere else they will not 
//              be included in the code that will be used when your algorithm is tested - and therefore your 
//              code will not compile.  You should not change the evaluate method.  You can add code to the 
//              main method, but any changes that you make should be only for testing purposes, as these 
//              changes will not be included in the code that will be used when your project is tested.
public class CombinationGuesser {

	String schoolName = "";  // set this string equal to your school's name.
	
	// if you want to add any class level variables or other methods, you must add them here.
	
	
	// method: guess
	// description: This is the one method that you should modify.  It is passed the last guess that was 
	//              made along with the evaluation for that guess.  You should use this information to make 
	//              an informed guess about the combination.
	// parameters: String lastGuess: The last guess that was made.
	//             String evaluation: A collections of '0's and '1's that represent how the last guess was
	//                                evaluated.
	// return: The next guess. Right now this method will just return a random guess. You should improve
	//         this method so that it uses what you know about the last guess to make a more educated.
	public static String guess(String lastGuess, String evaluation){
		// This will randomly generate a 4-digit combination. Each digit will be between 0 and 5, inclusive.
		// 48 is added to each digit because these digits are being concatenated to a String as chars and  
		// '0' has an ascii value of 48, '1' has an ascii value of '49', '2' has an ascii value of '50', etc.
		return "" + (char)((Math.random()*6)+48) + (char)((Math.random()*6)+48) + 
				(char)((Math.random()*6)+48) + (char)((Math.random()*6)+48);
	}

	// method: evaluate
	// description: This method is passed a guess and the actual combination.  It will construct a String
	//              of '0's and '1's that represents how many digits in the guess are correct. '0' means
	//              correct digit at correct location, '1' means correct digit at the wrong location.
	// parameters:  String guess: The guess that will be evaluated.
	//              String combination:  The correct combination.
	public static String evaluate(String guess, String combination){

		StringBuilder eval = new StringBuilder("----");

		for(int i= 0; i< guess.length(); i++){
			if(guess.charAt(i) == combination.charAt(i))
				eval.setCharAt(i, '0');;		
		}

		for(int i= 0; i<4; i++){
			for(int j=0; j<4; j++){
				if(eval.charAt(j) == '-' && guess.charAt(i) == combination.charAt(j)){
					eval.setCharAt(i, '1');
				}
			}
		}
		return eval.toString();
	}
	
	// method: main
	// description: This is the class's main method.  You can edit this method, but any changes that you make
	//              will not be used when your algorithm is tested.
	public static void main(String[] args){

		// This will randomly generate a 4-digit combination.  Each digit will be between 0 and 5, inclusive.
		// 48 is added to each digit because these digits are being concatenated to a String as chars and  
		// '0' has an ascii value of 48, '1' has an ascii value of '49', '2' has an ascii value of '50', etc. 
		// Although you have access to this variable to test your algorithm, it is important to understand that
		// will not be able to access it when your algorithm is tested by the judges.
		String combination = "";
		for(int i=0; i<4; i++)
			combination+=(char)((Math.random()*6)+48);
		System.out.println("The combination is " + combination);
		
		// Used to keep track of how many guesses it takes to find the correct combination.
		int totalGuesses = 0;                     

		// These strings will be used to keep track of each guess that you make, and what that guess 
		// evaluates to.  Starts with '9999', which would return a evaluation of '----'.
		String lastGuess = "9999";
		String evaluation = "----";
		
		// This loop will continue until your guess matches the correct combination.
		do{
			lastGuess = guess(lastGuess, evaluation);
			evaluation = evaluate(lastGuess, combination);
			System.out.println(lastGuess + " " + evaluation);
			totalGuesses++;
		}while(!lastGuess.equals(combination));
		System.out.println("It took " + totalGuesses + " guesses.");
	}
}
