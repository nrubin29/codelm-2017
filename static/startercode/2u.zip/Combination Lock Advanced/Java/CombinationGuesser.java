// class: CombinationGuesser
// written by: Mr. Swope
// date: 2/6/17
// description: This class must contain the method guess with the method signature that is shown below.
//              You also need to set the String SCHOOL_NAME equal to your school's name.  You can add any
//              other instance fields or methods that you would like, however these methods will not be
//              called when your algorithm is tested unless you actually call them inside of this class.
//
//              When your code is tested, a new instance of your class will in instantiated using the 
//              class's default constructor.  The method guess will then be repeatedly called until the 
//              correct combination is guessed.
public class CombinationGuesser {

	public static final String schoolName = "";  // set this string equal to your school's name.
	
	public CombinationGuesser(){
		
	}
	// method: guess
	// description: This method is passed the last guess that was made along with the evaluation for that
	//              guess.  You should use this information to make an informed guess about the combination.            
	// parameters: String lastGuess: The last guess that was made.
	//             String evaluation: A collections of '0's and '1's that represent how the last guess was
	//                                evaluated.
	// return: The next guess. Right now this method will just return a random guess. You should improve
	//         this method so that it uses what you know about the last guess to make a more educated.
	public String guess(String lastGuess, String evaluation){	
		// This will randomly generate a 4-digit combination. Each digit will be between 0 and 5, inclusive.
		// 48 is added to each digit because these digits are being concatenated to a String as chars and  
		// '0' has an ascii value of 48, '1' has an ascii value of '49', '2' has an ascii value of '50', etc.
		return "" + (char)((Math.random()*6)+48) + (char)((Math.random()*6)+48) + 
				(char)((Math.random()*6)+48) + (char)((Math.random()*6)+48);
	}
}
