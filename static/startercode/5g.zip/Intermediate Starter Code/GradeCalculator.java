import java.util.Scanner;

public class GradeCalculator {
	
	static Scanner s = new Scanner(System.in);
	//	Write a program that inputs a series of non-negative integers between 0 and 100 and prints out what letter grade 
	//  each of these scores would translate too.
	//  Do not print anything else or your solution will be marked wrong.
	//	When you are finished, copy and paste the the entire contents of this file into the employee
	//	dashboard to test your algorithm.
	public static void main(String[] args) {
	
	
		
		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                     // print your answer and just your answer.

	}

}
