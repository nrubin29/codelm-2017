import java.util.Scanner;

public class SpecialSequence {

	static Scanner s = new Scanner(System.in);
	//  Write a program that inputs a series of non-negative integers. The first negative value will terminate the 
	//  input. The program determines and prints the number of input integers that are divisible by 6 and their average.
	//  Do not print anything else or your solution will be marked wrong.
	//	When you are finished, copy and paste the the entire contents of this file into the employee
	//	dashboard to test your algorithm.
	public static void main(String[] args) {
		

	}

}
